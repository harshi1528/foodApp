import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import Cookies from 'js-cookie';
import '../Styles/Login.css';

const Login = () => {
  const [emailId, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [Role, setRole] = useState('User'); // Default role is "User"
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleLogin = async () => {
    try {
      const response = await axios.post(`https://localhost:7192/api/auth/login/${Role}`, { emailId, password, Role });
      const { token } = response.data;
      // Store token in cookie
      Cookies.set('token', token);
      console.log('Login successful. Token:', token);
      // Redirect to the appropriate dashboard based on the role
      if (Role === 'Admin') {
        navigate('/admindashboard');
      } else {
        navigate('/dashboard');
      }
    } catch (error) {
      if (error.response && error.response.data && error.response.data.message) {
        setError("Failed to log in. Please check your credentials.");
      } else {
        setError("An unexpected error occurred. Please try again later.");
      }
    }
  };

  const handleSignup = () => {
    navigate('/');
  };

  return (
    <div>
      <nav className="navbar">
        <span className="navbar-title">Restaurant Management System</span>
      </nav>
      <div className="login-container">
        <h2>Login</h2>
        <input type="text" placeholder="Email" value={emailId} onChange={(e) => setEmail(e.target.value)} />
        <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
        <select value={Role} onChange={(e) => setRole(e.target.value)}>
          <option value="User">User</option>
          <option value="Admin">Admin</option>
        </select>
        <button onClick={handleLogin}>Login</button>
        <div>New user? Sign up here!</div>
        <button onClick={handleSignup}>Sign Up</button>
        {error && <div className="error-message">{error}</div>}
      </div>
    </div>
  );
};

export default Login;