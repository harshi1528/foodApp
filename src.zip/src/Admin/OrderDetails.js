// OrderDetails.js

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../Styles/OrderDetails.css'; // Import CSS file for styling
import AdminPanel from '../Component/AdminPanel';

const OrderDetails = () => {
  const [orders, setOrders] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const response = await axios.get('https://localhost:7192/api/Orders');
        console.log(response.data);
        setOrders(response.data.$values || []); // Ensure orders is initialized as an array
      } catch (error) {
        console.error('Error fetching orders:', error);
        setError('Failed to fetch orders. Please try again later.');
      }
    };

    fetchOrders();
  }, []);

  return (
    <div>
        <AdminPanel/>
    <div className="order-details-container">
      <h2>Order Details</h2>
      {error && <div className="error-message">{error}</div>}
      <table>
        <thead>
          <tr>
            <th>Order ID</th>
            <th>Order Date</th>
            <th>Item Name</th>
            <th>Price</th>
            <th>Quantity</th>
          </tr>
        </thead>
        <tbody>
          {orders.map(order => (
            <tr key={order.orderId}>
              <td>{order.orderId}</td>
              <td>{order.orderDate}</td>
              <td>{order.itemName}</td>
              <td>{order.price}</td>
              <td>{order.quantity}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
    </div>
  );
};

export default OrderDetails;